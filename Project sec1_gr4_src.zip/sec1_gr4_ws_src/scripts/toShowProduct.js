function Function1() {
    var close1 = document.getElementById("close1");
    var more1Text = document.getElementById("more1");
    var check1Text = document.getElementById("check1");
  
    if (close1.style.display === "none") {
      close1.style.display = "inline";
      check1Text.innerHTML = "Read more";
      more1Text.style.display = "none";
    } else {
      close1.style.display = "none";
      check1Text.innerHTML = "Read less";
      more1Text.style.display = "inline";
    }
}

function Function2() {
    var close2 = document.getElementById("close2");
    var more2Text = document.getElementById("more2");
    var check2Text = document.getElementById("check2");
  
    if (close2.style.display === "none") {
      close2.style.display = "inline";
      check2Text.innerHTML = "Read more";
      more2Text.style.display = "none";
    } else {
      close2.style.display = "none";
      check2Text.innerHTML = "Read less";
      more2Text.style.display = "inline";
    }
}

function Function3() {
    var close3 = document.getElementById("close3");
    var more3Text = document.getElementById("more3");
    var check3Text = document.getElementById("check3");
  
    if (close3.style.display === "none") {
      close3.style.display = "inline";
      check3Text.innerHTML = "Read more";
      more3Text.style.display = "none";
    } else {
      close3.style.display = "none";
      check3Text.innerHTML = "Read less";
      more3Text.style.display = "inline";
    }
}

function Function4() {
    var close4 = document.getElementById("close4");
    var more4Text = document.getElementById("more4");
    var check4Text = document.getElementById("check4");
  
    if (close4.style.display === "none") {
      close4.style.display = "inline";
      check4Text.innerHTML = "Read more";
      more4Text.style.display = "none";
    } else {
      close4.style.display = "none";
      check4Text.innerHTML = "Read less";
      more4Text.style.display = "inline";
    }
}

function Function5() {
    var close5 = document.getElementById("close5");
    var more5Text = document.getElementById("more5");
    var check5Text = document.getElementById("check5");
  
    if (close5.style.display === "none") {
      close5.style.display = "inline";
      check5Text.innerHTML = "Read more";
      more5Text.style.display = "none";
    } else {
      close5.style.display = "none";
      check5Text.innerHTML = "Read less";
      more5Text.style.display = "inline";
    }
}

function Function6() {
    var close6 = document.getElementById("close6");
    var more6Text = document.getElementById("more6");
    var check6Text = document.getElementById("check6");
  
    if (close6.style.display === "none") {
      close6.style.display = "inline";
      check6Text.innerHTML = "Read more";
      more6Text.style.display = "none";
    } else {
      close6.style.display = "none";
      check6Text.innerHTML = "Read less";
      more6Text.style.display = "inline";
    }
}

function Function7() {
    var close7 = document.getElementById("close7");
    var more7Text = document.getElementById("more7");
    var check7Text = document.getElementById("check7");
  
    if (close7.style.display === "none") {
      close7.style.display = "inline";
      check7Text.innerHTML = "Read more";
      more7Text.style.display = "none";
    } else {
      close7.style.display = "none";
      check7Text.innerHTML = "Read less";
      more7Text.style.display = "inline";
    }
}

function Function8() {
    var close8 = document.getElementById("close8");
    var more8Text = document.getElementById("more8");
    var check8Text = document.getElementById("check8");
  
    if (close8.style.display === "none") {
      close8.style.display = "inline";
      check8Text.innerHTML = "Read more";
      more8Text.style.display = "none";
    } else {
      close8.style.display = "none";
      check8Text.innerHTML = "Read less";
      more8Text.style.display = "inline";
    }
}

function f1() {
    var hide1 = document.getElementById("hide1");
    var make1Text = document.getElementById("make1");
    var show1Text = document.getElementById("show1");
  
    if (hide1.style.display === "none") {
      hide1.style.display = "inline";
      show1Text.innerHTML = "Tea making";
      make1Text.style.display = "none";
    } else {
      hide1.style.display = "none";
      show1Text.innerHTML = "Close";
      make1Text.style.display = "inline";
    }
}

function f2() {
    var hide2 = document.getElementById("hide2");
    var make2Text = document.getElementById("make2");
    var show2Text = document.getElementById("show2");
  
    if (hide2.style.display === "none") {
      hide2.style.display = "inline";
      show2Text.innerHTML = "Tea making";
      make2Text.style.display = "none";
    } else {
      hide2.style.display = "none";
      show2Text.innerHTML = "Close";
      make2Text.style.display = "inline";
    }
}

function f3() {
    var hide3 = document.getElementById("hide3");
    var make3Text = document.getElementById("make3");
    var show3Text = document.getElementById("show3");
  
    if (hide3.style.display === "none") {
      hide3.style.display = "inline";
      show3Text.innerHTML = "Tea making";
      make3Text.style.display = "none";
    } else {
      hide3.style.display = "none";
      show3Text.innerHTML = "Close";
      make3Text.style.display = "inline";
    }
}

function f4() {
    var hide4 = document.getElementById("hide4");
    var make4Text = document.getElementById("make4");
    var show4Text = document.getElementById("show4");
  
    if (hide4.style.display === "none") {
      hide4.style.display = "inline";
      show4Text.innerHTML = "Tea making";
      make4Text.style.display = "none";
    } else {
      hide4.style.display = "none";
      show4Text.innerHTML = "Close";
      make4Text.style.display = "inline";
    }
}

function f5() {
    var hide5 = document.getElementById("hide5");
    var make5Text = document.getElementById("make5");
    var show5Text = document.getElementById("show5");
  
    if (hide5.style.display === "none") {
      hide5.style.display = "inline";
      show5Text.innerHTML = "Tea making";
      make5Text.style.display = "none";
    } else {
      hide5.style.display = "none";
      show5Text.innerHTML = "Close";
      make5Text.style.display = "inline";
    }
}

function f6() {
    var hide6 = document.getElementById("hide6");
    var make6Text = document.getElementById("make6");
    var show6Text = document.getElementById("show6");
  
    if (hide6.style.display === "none") {
      hide6.style.display = "inline";
      show6Text.innerHTML = "Tea making";
      make6Text.style.display = "none";
    } else {
      hide6.style.display = "none";
      show6Text.innerHTML = "Close";
      make6Text.style.display = "inline";
    }
}

function f7() {
    var hide7 = document.getElementById("hide7");
    var make7Text = document.getElementById("make7");
    var show7Text = document.getElementById("show7");
  
    if (hide7.style.display === "none") {
      hide7.style.display = "inline";
      show7Text.innerHTML = "Tea making";
      make7Text.style.display = "none";
    } else {
      hide7.style.display = "none";
      show7Text.innerHTML = "Close";
      make7Text.style.display = "inline";
    }
}

function f8() {
    var hide8 = document.getElementById("hide8");
    var make8Text = document.getElementById("make8");
    var show8Text = document.getElementById("show8");
  
    if (hide8.style.display === "none") {
      hide8.style.display = "inline";
      show8Text.innerHTML = "Tea making";
      make8Text.style.display = "none";
    } else {
      hide8.style.display = "none";
      show8Text.innerHTML = "Close";
      make8Text.style.display = "inline";
    }
}
 
var mybutton = document.getElementById("myBtn");
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block"; 
  } else {
    mybutton.style.display = "none";
  }
}

function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}